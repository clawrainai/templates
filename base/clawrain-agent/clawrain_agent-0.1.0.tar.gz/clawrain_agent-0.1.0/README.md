# ClawRain Agent 🌧️

Agent-side metrics API for the ClawRain trading platform.

Runs on your VPS alongside your OpenClaw agent. Exposes real-time trading metrics via a FastAPI server that the ClawRain dashboard consumes.

## Install

```bash
# From the ClawRain Hub (recommended):
pip install https://YOUR_CLAWRAIN_HUB_URL/clawrain_agent-0.1.0.tar.gz

# Or from PyPI (when published):
pip install clawrain-agent
```

## Usage

```bash
# 1. Initialize (creates SQLite DB, detects endpoints)
clawrain-agent init --config setup-config.json

# 2. Start the metrics server
clawrain-agent start --config setup-config.json --port 8000

# 3. Push daily snapshot to Hub (run via cron)
clawrain-agent snapshot --config setup-config.json
```

## How It Works

1. Reads your `setup-config.json` (from ClawRain Hub onboarding)
2. Scans `skills/` directory for installed trading strategies
3. Auto-detects available data sources (strategy registries, DSL state, scanner output)
4. Exposes a `/manifest` endpoint describing all available widgets
5. The ClawRain dashboard reads the manifest and renders widgets dynamically

## Endpoints

| Endpoint | Source | Widget | Description |
|---|---|---|---|
| `/manifest` | auto | — | Lists all available endpoints + widget config |
| `/health` | local | StatusGrid | MCP connection, skills, crons |
| `/positions` | Senpi realtime | DataTable | Open positions with PnL |
| `/portfolio` | Senpi realtime | MetricCard | Balance, PnL, drawdown |
| `/dsl-status` | state files | StatusGrid | Trailing stop phases |
| `/scanner` | state files | BadgeList | Latest scanner signals |
| `/pnl-history` | SQLite | LineChart | Historical PnL chart |
| `/trades` | SQLite | DataTable | Closed trade history |

## Auth

All endpoints (except `/health`) require the `X-Agent-Key` header matching the `api_key` from your setup config. The ClawRain Hub proxy injects this automatically.

## License

MIT
